# Voice Symphony: MUS/COS314 Project

To run:

First, execute run.sh in the terminal. 
Then, open voice_symphony.maxpat using Max/MSP and follow instructions. 

----
## changelog
* 13-Jan-2019 initialization 

----
## Thanks
* Jeff Snyder and Alex Dowling 

